package com.rikesh.hisab.entity;
import jakarta.persistence.*;import java.time.Instant;
@Entity @Table(name="documents") public class Document{@Id @GeneratedValue(strategy=GenerationType.UUID) public String id;public String ownerId,customerId,transactionId,filename,fileType,storagePath;public long fileSize;public Instant uploadedAt=Instant.now();}
