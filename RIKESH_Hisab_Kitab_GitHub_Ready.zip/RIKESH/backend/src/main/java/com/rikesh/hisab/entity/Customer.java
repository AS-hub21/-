package com.rikesh.hisab.entity;
import jakarta.persistence.*;import java.time.Instant;
@Entity @Table(name="customers",indexes={@Index(name="idx_customer_code",columnList="code",unique=true),@Index(name="idx_customer_phone",columnList="phone")})
public class Customer{@Id @GeneratedValue(strategy=GenerationType.UUID) public String id;@Column(nullable=false) public String code;@Column(nullable=false) public String name;public String phone,email,address,notes;public Instant createdAt=Instant.now();}
