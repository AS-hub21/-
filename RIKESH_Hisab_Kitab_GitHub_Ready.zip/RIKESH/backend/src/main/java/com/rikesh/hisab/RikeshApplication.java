package com.rikesh.hisab;
import org.springframework.boot.SpringApplication;import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class RikeshApplication{public static void main(String[] args){SpringApplication.run(RikeshApplication.class,args);}}
