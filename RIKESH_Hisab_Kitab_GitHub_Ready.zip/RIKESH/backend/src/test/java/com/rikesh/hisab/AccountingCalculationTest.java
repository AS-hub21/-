package com.rikesh.hisab;
import org.junit.jupiter.api.Test;import java.math.BigDecimal;import static org.junit.jupiter.api.Assertions.*;
class AccountingCalculationTest{@Test void netResult(){assertEquals(new BigDecimal("6000.00"),new BigDecimal("10000.00").subtract(new BigDecimal("4000.00")));}@Test void loss(){assertEquals(new BigDecimal("-6000.00"),new BigDecimal("4000.00").subtract(new BigDecimal("10000.00")));}@Test void customerBalance(){assertEquals(new BigDecimal("12000.00"),new BigDecimal("20000.00").subtract(new BigDecimal("8000.00")));}}
