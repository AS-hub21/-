#pragma once
#include <cstdint>
namespace rikesh { long double net(long double income,long double expense); long double customer_balance(long double got,long double give); long double cash(long double opening,long double in,long double out); }
