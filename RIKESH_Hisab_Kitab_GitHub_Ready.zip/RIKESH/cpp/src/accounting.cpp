#include "accounting.hpp"
namespace rikesh { long double net(long double income,long double expense){return income-expense;} long double customer_balance(long double got,long double give){return got-give;} long double cash(long double opening,long double in,long double out){return opening+in-out;} }
