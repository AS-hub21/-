#include "accounting.hpp"
#include <cassert>
#include <cmath>
int main(){assert(std::fabs((double)rikesh::net(10000,4000)-6000)<1e-9);assert(std::fabs((double)rikesh::net(4000,10000)+6000)<1e-9);assert(std::fabs((double)rikesh::customer_balance(20000,8000)-12000)<1e-9);assert(std::fabs((double)rikesh::cash(10000,5000,2000)-13000)<1e-9);}
