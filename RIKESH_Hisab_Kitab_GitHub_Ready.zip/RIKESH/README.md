# RIKESH — Personal Hisab Kitab

A modern Nepali-style personal accounting application for one owner. The repository contains:

- `frontend/` — responsive HTML/CSS/JavaScript SPA. It works on GitHub Pages using browser persistence, with no build step.
- `backend/` — Java 21 + Spring Boot REST API starter for production persistence/authentication.
- `cpp/` — optional standalone financial calculation module; the web app does not depend on it.

## GitHub Pages
1. Create a GitHub repository.
2. Upload the contents of this folder.
3. In **Settings → Pages**, select **GitHub Actions**.
4. The included workflow publishes `frontend/`.

The frontend has a local/browser mode so it is immediately usable on GitHub Pages. **Do not treat browser storage as secure production accounting storage.** For real deployment with sensitive documents, run the Java backend with PostgreSQL/private file storage and connect the frontend API.

## Local frontend
Open `frontend/index.html` directly, or serve the repository with any static server.

## Backend
Requires Java 21 and Maven. From `backend/`:

```bash
mvn spring-boot:run
```

Default development profile uses H2. PostgreSQL configuration is included in `application-prod.properties`.

## Demo login
Frontend demo mode accepts any non-empty username/password and stores a local session. This is intentionally a convenience mode for GitHub Pages; it is **not** a security boundary. Production authentication belongs in the backend.

## Important accounting rules
- Money amounts are stored as positive values; transaction type determines direction.
- Customer balance = You Got − You Give.
- Unpaid customer credit does not increase cash.
- Monetary backend values use `BigDecimal`.
- Timezone is Asia/Kathmandu.
