# Deployment notes

## Fastest: GitHub Pages
This publishes `frontend/` and is suitable for a personal/demo browser-only deployment. Enable the GitHub Pages workflow after pushing to `main`.

**Limitation:** browser localStorage is not a secure database. Anyone using a different browser/device will not see the data, and sensitive documents should not be stored this way.

## Production architecture
Use the included Java backend + PostgreSQL:

1. Build `backend` with Maven and Java 21.
2. Set `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` and strong `RIKESH_ADMIN_USER`, `RIKESH_ADMIN_PASSWORD` environment variables.
3. Set `RIKESH_UPLOAD_DIR` to a private directory or replace the local filesystem storage with private object storage.
4. Run the backend behind HTTPS.
5. Configure the frontend API base URL and replace browser-only persistence with authenticated API calls.
6. Restrict CORS to the actual frontend origin rather than `*` before production.

The Java API uses BigDecimal and the C++ module is optional. The browser never depends on C++.
